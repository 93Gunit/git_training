/*
 * Packing knapsack question
 *
 * Copyright (C) 2016, Taeung Song <treeze.taeung@gmail.com>
 *
 */
#include <stdio.h>

void grade_price_per_wgt(int price_per_wgt_list[])
{
	/* Arrange each value in order of price per 1 weight */
}

int get_nr_of_try(int kinds)
{
	/* Get the number of try that check whether
	 * some result value is most close to theoretical maximum
	 */
}

int get_theor_maximum(int price_per_wgt_list[])
{
	/* Get a theoretical maximum following the highest
	 * price per 1 weight.
	 */
}

int get_cond_maximum(int price_per_wgt_list[], int exclu_index,
		     int vital_index)
{
	/* Get a maximum with condition that some values
	 * should be included or excluded.
	 */
}

int main(int argc, const char **argv)
{
}
